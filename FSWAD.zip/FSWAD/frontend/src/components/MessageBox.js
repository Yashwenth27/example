import React from "react";

export default function MessageBox({ text, type }) {
  if (!text) return null;

  const className = type === "error" ? "message error" : "message success";
  return <div className={className}>{text}</div>;
}
