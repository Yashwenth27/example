import React from "react";
import {Link} from "react-router-dom";

import "bootstrap/dist/css/bootstrap.min.css";

export default function Navbar() {
    return (
        <nav className="navbar px-3">
            <h1 className="navbar-brand">Book Inventory</h1>
                <ul className="nav">
                <li className="nav-item"><Link to="/">Home |</Link></li>
                <li><Link to="/add">Add |</Link></li>
                <li><Link to="/search">Search |</Link></li>
                <li><Link to="/update">Update |</Link></li>
                <li><Link to="/delete">Delete |</Link></li>
            </ul>
        </nav>
    )
}