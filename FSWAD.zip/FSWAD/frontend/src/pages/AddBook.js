import React, { useState } from "react";
import { API_URL } from "../api";
import FormInput from "../components/FormInput";

export default function AddBook({showMessage}){
    const [formData,setFormData] = useState({
        BookTitle:"",
        ISBN:"",
        Quantity:""
    });
    const handleChange = (e) => {
        const {name,value} = e.target;
        setFormData({...formData,[name]:value});
    };
    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch(`${API_URL}/add`,{
                method: "POST",
                headers: {"Content-Type":"application/json"},
                body: JSON.stringify(formData)
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.error || "Failed to add book");
            console.log(`Book "${data.book.BookTitle}" added successfully!`);
            setFormData({ BookTitle: "", ISBN: "", Author: "", Category: "", Quantity: "" });
        } catch (error) {
            console.log(error.message,"error");
        }
    }

    return (
        <div>
        <h2>Add a New Book</h2>
        <form onSubmit={handleSubmit}>
            <FormInput label="Book Title" name="BookTitle" value={formData.BookTitle} onChange={handleChange} required />
            <FormInput label="ISBN" name="ISBN" value={formData.ISBN} onChange={handleChange} required />
            <FormInput label="Quantity" name="Quantity" type="number" value={formData.Quantity} onChange={handleChange} required />
            <button type="submit" className="btn-primary">Add Book</button>
        </form>
        </div>
    )
}