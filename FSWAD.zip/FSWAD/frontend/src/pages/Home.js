import React from "react";

export default function Home() {
  return (
    <div>
      <h2>Welcome to the Book Inventory Management System</h2>
      <p>Use the navigation bar to add, search, delete, or display books.</p>
      <p>This app uses React (frontend) and Node.js/Express (backend).</p>
    </div>
  );
}
