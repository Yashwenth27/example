import React, { useState, useEffect } from 'react';

// --- API Configuration ---
// This is the base URL of your running backend
const API_URL = 'http://localhost:5000/books';

/**
 * Main App Component
 * This component manages navigation and renders the active page.
 */
export default function App() {
  // 'page' state controls which component to display
  const [page, setPage] = useState('home');

  // Utility state for showing success/error messages
  const [message, setMessage] = useState({ text: '', type: '' });

  // Function to show a message for a few seconds
  const showMessage = (text, type = 'success') => {
    setMessage({ text, type });
    setTimeout(() => {
      setMessage({ text: '', type: '' });
    }, 3000);
  };

  // Helper function to render the correct page based on state
  const renderPage = () => {
    switch (page) {
      case 'add':
        return <AddBook showMessage={showMessage} />;
      case 'search':
        return <SearchBook showMessage={showMessage} />;
      case 'delete':
        return <DeleteBook showMessage={showMessage} />;
      case 'display':
        return <DisplayAllBooks showMessage={showMessage} />;
      case 'home':
      default:
        return <Home />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 font-sans">
      <Navbar setPage={setPage} />
      {message.text && (
        <MessageBox text={message.text} type={message.type} />
      )}
      <main className="p-4 md:p-8">
        <div className="max-w-4xl mx-auto bg-white p-6 rounded-xl shadow-md">
          {renderPage()}
        </div>
      </main>
    </div>
  );
}

/**
 * Navigation Bar Component
 */
function Navbar({ setPage }) {
  const navItems = [
    { name: 'Home', page: 'home' },
    { name: 'Add Book', page: 'add' },
    { name: 'Search Book', page: 'search' },
    { name: 'Delete Book', page: 'delete' },
    { name: 'Display All', page: 'display' },
  ];

  return (
    <nav className="bg-blue-600 text-white p-4 shadow-md">
      <div className="max-w-4xl mx-auto flex flex-col md:flex-row justify-between items-center">
        <h1 className="text-2xl font-bold mb-2 md:mb-0">Book Inventory</h1>
        <ul className="flex flex-wrap justify-center space-x-2">
          {navItems.map((item) => (
            <li key={item.page}>
              <button
                onClick={() => setPage(item.page)}
                className="px-3 py-2 rounded-md text-sm font-medium hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-white"
              >
                {item.name}
              </button>
            </li>
          ))}
        </ul>
      </div>
    </nav>
  );
}

/**
 * Home Page Component
 */
function Home() {
  return (
    <div>
      <h2 className="text-3xl font-bold text-gray-800 mb-4">Welcome to the Book Inventory Management System</h2>
      <p className="text-gray-600">
        Use the navigation bar above to add, search, delete, or display books in the database.
      </p>
      <p className="text-gray-600 mt-2">
        This application is powered by a React frontend and a Node.js/Express backend.
      </p>
    </div>
  );
}

/**
 * Add Book Page Component
 */
function AddBook({ showMessage }) {
  const [formData, setFormData] = useState({
    BookTitle: '',
    ISBN: '',
    Author: '',
    Category: '',
    Quantity: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Simple validation
    if (!formData.BookTitle || !formData.ISBN || !formData.Author || !formData.Quantity) {
      showMessage('Please fill in all required fields (Title, ISBN, Author, Quantity).', 'error');
      return;
    }

    try {
      const response = await fetch(`${API_URL}/add`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to add book');
      }

      showMessage(`Book "${data.book.BookTitle}" added successfully!`);
      // Clear the form
      setFormData({
        BookTitle: '',
        ISBN: '',
        Author: '',
        Category: '',
        Quantity: '',
      });
    } catch (error) {
      console.error('Error adding book:', error);
      showMessage(error.message, 'error');
    }
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Add a New Book</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <FormInput label="Book Title" name="BookTitle" value={formData.BookTitle} onChange={handleChange} required />
        <FormInput label="ISBN" name="ISBN" value={formData.ISBN} onChange={handleChange} required />
        <FormInput label="Author" name="Author" value={formData.Author} onChange={handleChange} required />
        <FormInput label="Category" name="Category" value={formData.Category} onChange={handleChange} />
        <FormInput label="Quantity" name="Quantity" type="number" value={formData.Quantity} onChange={handleChange} required />
        <button
          type="submit"
          className="w-full bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400"
        >
          Add Book
        </button>
      </form>
    </div>
  );
}

/**
 * Search Book Page Component
 */
function SearchBook({ showMessage }) {
  const [isbn, setIsbn] = useState('');
  const [book, setBook] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!isbn) {
      showMessage('Please enter an ISBN to search.', 'error');
      return;
    }
    
    setIsLoading(true);
    setBook(null); // Clear previous results

    try {
      const response = await fetch(`${API_URL}/isbn/${isbn}`);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to find book');
      }

      setBook(data);
    } catch (error) {
      console.error('Error searching book:', error);
      showMessage(error.message, 'error');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Search Book by ISBN</h2>
      <form onSubmit={handleSubmit} className="flex space-x-2 mb-4">
        <FormInput label="Enter ISBN" name="isbn" value={isbn} onChange={(e) => setIsbn(e.target.value)} required hideLabel />
        <button
          type="submit"
          disabled={isLoading}
          className="bg-green-500 text-white py-2 px-4 rounded-md hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-green-400 disabled:bg-gray-400"
        >
          {isLoading ? 'Searching...' : 'Search'}
        </button>
      </form>

      {book && (
        <div className="bg-gray-50 p-4 rounded-lg shadow">
          <h3 className="text-xl font-semibold">{book.BookTitle}</h3>
          <p className="text-gray-700"><strong>Author:</strong> {book.Author}</p>
          <p className="text-gray-700"><strong>ISBN:</strong> {book.ISBN}</p>
          <p className="text-gray-700"><strong>Category:</strong> {book.Category || 'N/A'}</p>
          <p className="text-gray-700"><strong>Quantity:</strong> {book.Quantity}</p>
        </div>
      )}
    </div>
  );
}

/**
 * Delete Book Page Component
 */
function DeleteBook({ showMessage }) {
  const [isbn, setIsbn] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!isbn) {
      showMessage('Please enter an ISBN to delete.', 'error');
      return;
    }

    // A simple confirmation before deleting
    if (!window.confirm('Are you sure you want to delete this book? This action cannot be undone.')) {
        return;
    }

    try {
      const response = await fetch(`${API_URL}/delete/${isbn}`, {
        method: 'DELETE',
      });
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to delete book');
      }

      showMessage(`Book "${data.book.BookTitle}" (ISBN: ${isbn}) deleted successfully.`);
      setIsbn(''); // Clear the input field
    } catch (error) {
      console.error('Error deleting book:', error);
      showMessage(error.message, 'error');
    }
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Delete Book by ISBN</h2>
      <form onSubmit={handleSubmit} className="flex space-x-2">
        <FormInput label="Enter ISBN" name="isbn" value={isbn} onChange={(e) => setIsbn(e.target.value)} required hideLabel />
        <button
          type="submit"
          className="bg-red-500 text-white py-2 px-4 rounded-md hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-400"
        >
          Delete Book
        </button>
      </form>
    </div>
  );
}

/**
 * Display All Books Page Component
 * As requested, this displays all books in a <textarea>
 */
function DisplayAllBooks({ showMessage }) {
  const [booksText, setBooksText] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // This function is called when the component mounts
    const fetchBooks = async () => {
      setIsLoading(true);
      try {
        const response = await fetch(API_URL);
        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.error || 'Failed to fetch books');
        }

        // Format the books array into a human-readable string for the textarea
        const formattedText = data.map(book => (
          `Title: ${book.BookTitle}\n` +
          `Author: ${book.Author}\n` +
          `ISBN: ${book.ISBN}\n` +
          `Category: ${book.Category || 'N/A'}\n` +
          `Quantity: ${book.Quantity}\n` +
          `----------------------------------`
        )).join('\n\n');
        
        setBooksText(formattedText || 'No books found in the database.');

      } catch (error) {
        console.error('Error fetching books:', error);
        showMessage(error.message, 'error');
        setBooksText(`Error: ${error.message}`);
      } finally {
        setIsLoading(false);
      }
    };

    fetchBooks();
  }, [showMessage]); // Re-run if showMessage changes (it won't, but it's good practice)

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-800 mb-4">All Books in Inventory</h2>
      {isLoading ? (
        <p>Loading books...</p>
      ) : (
        <textarea
          readOnly
          value={booksText}
          className="w-full h-96 p-3 border border-gray-300 rounded-md bg-gray-50 font-mono text-sm"
        />
      )}
    </div>
  );
}

/**
 * Reusable Form Input Component
 */
function FormInput({ label, name, type = 'text', value, onChange, required = false, hideLabel = false }) {
  return (
    <div>
      {!hideLabel && (
        <label htmlFor={name} className="block text-sm font-medium text-gray-700 mb-1">
          {label} {required && <span className="text-red-500">*</span>}
        </label>
      )}
      <input
        type={type}
        id={name}
        name={name}
        value={value}
        onChange={onChange}
        required={required}
        placeholder={hideLabel ? label : ''}
        className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
      />
    </div>
  );
}

/**
 * Message Box Component
 * Replaces the need for alert()
 */
function MessageBox({ text, type }) {
  const isError = type === 'error';
  const bgColor = isError ? 'bg-red-100' : 'bg-green-100';
  const borderColor = isError ? 'border-red-400' : 'border-green-400';
  const textColor = isError ? 'text-red-700' : 'text-green-700';

  return (
    <div className={`fixed top-20 right-5 p-4 border ${borderColor} rounded-md ${bgColor} ${textColor} shadow-lg z-50`}>
      {text}
    </div>
  );
}
