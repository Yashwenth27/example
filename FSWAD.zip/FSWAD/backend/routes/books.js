const router = require('express').Router();
let Book = require("../models/books.model");

router.get("/",async(req,res)=>{
    try {
        const books = await Book.find();
        res.status(200).json(books);
    } catch (error) {
        res.status(400).json({error: "Error fetching books : "+error.message});
    }
});

router.get('/isbn/:isbn',async(req,res)=>{
    try {
        const isbn = req.params.isbn;
        const books = await Book.findOne({ISBN:isbn});
        if (!books) {
            return res.status(404).json({error:"No book with that ISBN"});
        }
        res.status(200).json(books);
    } catch (error) {
        res.status(400).json({error:"Error looking up for the ISBN : "+error.message});
    }
});

router.post('/add',async(req,res)=>{
    try {
        const {BookTitle,ISBN,Quantity} = req.body;
        const newBook = new Book({
            BookTitle,
            ISBN,
            Quantity : Number(Quantity)
        });
        await newBook.save();
        res.status(201).json({message:'Book added successfully',book : newBook});
    } catch (error) {
        res.status(400).json({error:"Error adding the book : "+error.message});
    }
});

router.delete('/delete/:isbn',async(req,res)=>{
    try {
        const isbn = req.params.isbn;
        const deletedBook = await Book.findOneAndDelete({ISBN:isbn});
        if (!deletedBook){
            return res.status(404).json({error:"No book with that ISBN number to delete"});
        }
        res.status(200).json({message:"Book deleted successfully",book:deletedBook});
    } catch (error) {
        res.status(400).json({error:"Error deleting the book : "+error.message});
    }
});

router.put('/update/:isbn',async(req,res)=>{
    try {
        const isbn = req.params.isbn;
        await Book.findOneAndUpdate({ISBN:isbn},req.body);
        res.status(200).json({message:"Update successfully"});
    } catch (error) {
        res.status(400).json({error:"Error updating : "+error.message});
    }
});

module.exports=router;
