const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");

const app = express();
const port = 5000;

app.use(cors());
app.use(express.json());

const uri = "mongodb://localhost:27017";

mongoose.connect(uri)
    .then(()=>{
        console.log("Mongo is OK");
    })
    .catch(err => {
        console.log("Mongo pochu :",err);
    });

const bookRouter = require("./routes/books");
app.use('/books',bookRouter);

app.listen(port,()=>{
    console.log("Server is listening at port 5000");
});