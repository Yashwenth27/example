const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const bookSchema = new Schema(
    {
        BookTitle : {
            type: String,
            required: true,
            trim: true
        },
        ISBN : {
            type: String,
            unique: true,
            trim: true,
            required: true
        },
        Quantity: {
            type: Number,
            required: true,
            min: 0 
        }
    },{
        timestamps: true,
    }
);
const Book = mongoose.model('Book',bookSchema);
module.exports = Book;